fx_version 'cerulean'
game 'gta5'

author 'JDRM'
description 'Wheelie tricks made by jd-development.'
version '1.0.0'

client_script 'client.lua'
