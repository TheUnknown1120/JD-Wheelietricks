RegisterCommand("nosemanualhop", function()
    local playerPed = PlayerPedId()
    if IsPedOnAnyBike(playerPed) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local pitch = GetEntityPitch(vehicle)
        
        if pitch < -5.0 then -- Check if the player is in a nose manual
            ApplyForceToEntity(vehicle, 1, 0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true) -- Increased hop force
            local startHeading = GetEntityHeading(vehicle)
            for i = 1, 36 do -- Smooth 360 rotation
                Citizen.Wait(10)
                SetEntityHeading(vehicle, startHeading + (i * 10))
            end
            Citizen.Wait(500) -- Duration of the hop
        else
            TriggerEvent("chat:addMessage", {args = {"[Trick]", "You must be in a nose manual!"}})
        end
    else
        TriggerEvent("chat:addMessage", {args = {"[Trick]", "You must be on a bike!"}})
    end
end, false)

RegisterKeyMapping("nosemanualhop", "Perform a Hop from Nose Manual", "keyboard", "LMENU")
